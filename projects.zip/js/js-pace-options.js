window.paceOptions =
    {
        ghostTime:1200
    }